import { Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "./components/Navbar";
import TrustedBy from "./components/TrustedBy";
import Divisions from "./components/Divisions";
import WhyChoose from "./components/WhyChoose";
import FeaturedProjects from "./components/FeaturedProjects";
import Home from "./Pages/Home";
import About from "./Pages/About";
//import Portfolio from "./Pages/Portfolio";
import Contact from "./Pages/Contact";
import ScrollToTop from "./components/ScrollToTop";

//import Media from "./Pages/Media";
import Digital from "./Pages/Digital";
import MusicProduction from "./Pages/MusicProduction";

function HomePage() {

  const location = useLocation();

useEffect(() => {

  if(location.state?.section) {

    setTimeout(() => {

      const section = document.getElementById(
        location.state.section
      );

      if(section) {

        section.scrollIntoView({
          behavior: "auto",
        });

      }

    }, 300);

  }

}, [location.state]);
  return (
    <>
      <div id="home">
        <Home />
      </div>

      <TrustedBy />

      <Divisions />

      <WhyChoose />

      <FeaturedProjects />

      <div id="about">
        <About />
      </div>

     

      <div id="contact">
        <Contact />
      </div>
    </>
  );
}
function App() {
  return (
    <>
      <ScrollToTop />

      <Navbar />

      <Routes>
        <Route path="/" element={<HomePage />} />

        

        <Route path="/digital" element={<Digital />} />

        <Route path="/music" element={<MusicProduction />} />
      </Routes>
    </>
  );
}

export default App;